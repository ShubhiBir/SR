#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(markdown)
library(nutshell)
library(DT)

shinyUI(fluidPage(
  
    # style for validation messages
    tags$head(
        tags$style(HTML("h4{font-family:sans-serif; }
        h1{font-family:sans-serif; }
        .shiny-output-error-validation { color: red;}"))
    ),
    
    # Application title
    headerPanel(h1("Sales Rewards Calculator")),
    
    ## sidebar containing input components
    sidebarPanel(
        
        helpText("Enter the Date of Birth, Retirement date, Increment start date, Premium, Rate. ",style='font-family:sans-serif'),
       # actionButton("eButton", "Calculate Rewards!"),
        hr(),
       
       
       textInput("Premium","Premium", value = "0"),
       selectInput("investmenttype", "Investment Type:",
                              c("Single Premium" = "SP",
                                "TransferIn" = "TV",
                                "Regular Premium" = "RP")),
        textInput("freq", "Premium Frequency(in case of RP):", value = "12" ),
        textInput("escalation", "Escalation percentage(RP):", value = "3"),
                  textInput("Rate", "Rate:", value = "1"),
                  #sliderInput("Rate", "Rate:", 0.01, min = 0.1, max = 3),
                  dateInput("Dateofbirth", "Date of Birth", value = "1986-01-01"), 
                  dateInput("Retirementdate", "Retirement Date", value = "2040-01-01"), 
                  dateInput("Incrementdate", "Commencement Date", value = "2014-01-01")
 
    ),
    
    # Includes the prediction andcomplete dataset represented as table and help file
    mainPanel(
        tabsetPanel(
            # prediction tab
            tabPanel("Sale Rewards Calculator", mainPanel(
                br(),
                h4("The calculated  rewards are:"),
                hr(),
          
               # h4('Previously evaluated Wine Mixes with Similar Characteristics'),
                #helpText("The table below shows rewards"),  
                
               tags$pre(HTML("<b>Rewards Calculated\t\t\t\t\t\t\tRewards to be paid</b>"),style='font-family:sens-serif;font-size:14px;'),
                fluidRow(
                  
                  br(),
                  column(width = 7,textOutput("Rewards_without_cap")),
                  column(width = 5,textOutput("Rewards_with_cap")),style='font-family:sans-serif;margin-left:0px;'
                  
                  #column(width = 12, checkboxInput('jitter', 'Jitter'))
                  
                ),
               
                #textOutput("Rewards_with_cap"), style = 'width:100%;',
               hr()
              # textOutput("Rewards_without_cap"), style = 'width:100%;'
               
            ))
        ))
))

