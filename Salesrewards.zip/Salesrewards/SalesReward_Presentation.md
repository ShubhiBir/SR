SalesReward_Presentation
========================================================
author: Shubhi
date: 25/07/2019
autosize: true

Objective:
========================================================


- Design the SalesReward calculator with easy to use interface.


Problem Statement:
========================================================



For the calculation of Premium depending upon type of increment.



Code Info
========================================================

You may access my Shinyapp page at https://shubhibir.shinyapps.io/ and and start using SalesReward calculator.
https://shubhibir.shinyapps.io/Salesrewards/



How To Use
========================================================

1. Enter the details in the left panel 
2. Any premium amount for which Sales rewards are to be calculated
3. Select Investment type from drop down
4. Select frequency as in for how much time you wish to hold the policy
5. Give escalation percentage in case you select Regular Premium
6. Give the rate of escalation
7. Give Date of birth post 1900
8. Retirement date should be > today's date
9. Commencement date should be greater than date of birth and before/on today's date

Since the application is reactive it will display Sales Rewards to be given to the Adviser/Broker/Agent.
