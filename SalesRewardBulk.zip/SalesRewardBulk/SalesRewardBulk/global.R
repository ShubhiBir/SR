




Logicfun<- function(df)
{
 
  newdf<-df
  
   #checking investment type
  if(df$investmenttype=="RP") 
  {if(varescalation>3 || varescalation==3){varpremium <- varpremium*varpremiumfreq*1.2} 
    else {varpremium <- varpremium*varpremiumfreq}
  }
  
  
  
  if((term<=25) && (retirementage<=65)) 
  {
    capterm<-term
    Rewards<-(varpremium*varrate*capterm)/1000   
  }
  
  else if((term<=25) && (retirementage>65))
  {
    if(incrementage<=65)
    { capterm<-abs(65-incrementage)
    if(capterm>25)
    {capterm<-25}
    }
    else 
    {
      if((retirementage-incrementage)>2){capterm=2}
      else{capterm<-abs(retirementage-incrementage)}
    }
    
    Rewards<-(varpremium*varrate*capterm)/1000
    
  }
  
  else if(term>25 && retirementage<65){
    
    capterm<-25
    Rewards<-(varpremium*varrate*capterm)/1000
    
  }
  
  else if(term>25 && retirementage>65){
    
    capterm<-abs(65-incrementage)
    if(capterm>25)
    {
      capterm<-25
    }
    # below code has been added later
    else 
    {
      if((retirementage-incrementage)>2){capterm=2}
      else{capterm<-abs(retirementage-incrementage)}
    }
    
    # ends
    Rewards<-(varpremium*varrate*capterm)/1000
    
  }
  
  Rewards_without_cap<-Rewards
  #capping on salesreward according to investmenttype
  if(df$investmenttype=="RP"||df$investmenttype=="SP"){if(Rewards>4000)Rewards<-4000}else if(df$investmenttype=="TV") {if(Rewards>10000)Rewards<-10000}
  
  
 # outputList<-list(Rewards_without_cap,Rewards)
  return(Rewards)
  
  
}

