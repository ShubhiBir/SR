#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(assertr)
library(shinyjs)
library(lubridate)
library(ggplot2)
library(anytime)
library('reticulate')
use_python("C:\\Users\\SHUBHI~1.BIR\\AppData\\Local\\Programs\\Python\\Python36\\python.exe")
#Py_SetPythonHome("C:\\Users\\SHUBHI~1.BIR\\AppData\\Local\\Programs\\Python\\Python38")
Sys.setenv(PATH = "C:\\Users\\shubhi.birla\\AppData\\Local\\Programs\\Python\\Python36")

# Define server logic 
shinyServer(function(input, output) {
    
    '%ni%' <- Negate('%in%')
    itypes <-c("RP","SP","TV")
    checkinv <-function(x){
        for(i in x){
            if( i %ni% itypes){
                stop("Investment type not valid-Only RP,SP,TV is allowed.")
            } 
        }
    }
    
   
    
    values<- reactiveValues(Data=NULL)
    observeEvent(input$input, {
        values$df_data <- read.csv(input$input$datapath)
    })
    
    observeEvent(input$Calculate,{
        output$contents<-Finalans
       
    })
    
   
    output$Download <- downloadHandler(
        filename = function() {
            paste("data-", Sys.Date(), ".csv", sep="")
        },   content = function(file) {
            write.csv(wcsv, file)
        }
    )
    Finalans <- renderDataTable({
        
        df<-as.data.frame(values$df_data)
        #input from file
        capterm<-1
        # varpremium <-1
        varrate<- as.double(df$Rate)
        vardob<- as.Date(df$Dateofbirth)
        varretdate<- as.Date(df$Retirementdate)
        varincstartdate<- as.Date(df$Incrementdate)
        varpremiumfreq<-(df$freq)
        varescalation<- (df$escalation)
        varinvtype<- (df$investmenttype)
        varpremiumfreq<-1
        Rewards<-1
        factor<-1
        
        
        currentAge<-abs(round((Sys.Date())- (as.Date(as.character(df$Dateofbirth,"%y-%m-%d"))),digits = 2)/365.25)*12
        incrementage<- abs(round((as.Date(as.character(df$Incrementdate,"%y-%m-%d")) - (as.Date(as.character(df$Dateofbirth,"%y-%m-%d")))),digits=2)/365.25)*12
        retirementage<-abs(round ((as.Date(as.character(df$Retirementdate,"%y-%m-%d")) - (as.Date(as.character(df$Dateofbirth,"%y-%m-%d")))),digits=2)/365.25)*12
        term<-abs(round ((as.Date(as.character(df$Retirementdate,"%y-%m-%d")) - (as.Date(as.character(df$Incrementdate,"%y-%m-%d")))),digits=2)/365.25)*12
        
        currentAge<-floor(currentAge)/12
        incrementage<-floor(incrementage)/12
        retirementage<-floor(retirementage)/12
        term<- floor(term)/12
        
        
        
        
        #logic
        #varpremium<-  ifelse(df$investmenttype == 'RP',ifelse(df$escalation>=3,df$Premium*1.2*df$freq,df$Premium*df$freq),df$Premium)
        varpremium<-  ifelse(df$investmenttype == 'RP',ifelse(df$escalation>=3,df$Premium*1.2*df$freq,df$Premium*df$freq),df$Premium)
        #df$CalculatedRewardswithoutcap<- (varpremium*df$rate*term)/1000
        cond1<- term<=25 & retirementage<=65
        cond2<- term>25 & retirementage<65
        cond3<- term<=25 & retirementage>65
        cond4<- incrementage<=65
        cond5<-(retirementage-incrementage)>2
        cond6<- abs(65-incrementage) >25
        cond7<- term>25 & retirementage>65
        cond10<-currentAge<65
        cond11<-currentAge+term>65
        
        
        cond8<- abs(65-incrementage)>25
        cond9<- (retirementage-incrementage)>2
        
        
        
        
        Rewards <-
            ifelse(cond1, 
                   (varpremium*varrate*term)/1000,
                   ifelse(cond2,
                          (varpremium*varrate*25)/1000,
                          ifelse(cond3,
                                 ifelse(cond4, ifelse(cond6, (varpremium*varrate*25)/1000, (varpremium*varrate* abs(65-incrementage))/1000),
                                        ifelse(cond5, (varpremium*varrate*2)/1000, (varpremium*varrate* abs(retirementage-incrementage))/1000)),
                                 ifelse(cond7, 
                                        ifelse(cond10,
                                               ifelse(cond11,		
                                                      ifelse(cond8, (varpremium*varrate*25)/1000,(varpremium*varrate* abs(65-incrementage))/1000),
                                                      ifelse(cond9, (varpremium*varrate*2)/1000, (varpremium*varrate* abs(retirementage-incrementage))/1000)),(varpremium*varrate*term)/1000),"Logic Not Applied")
                          )
                   )
            )
        
        
        
        
        
        
        
        
        
        
        
        #  df$incrementage<-incrementage
        # df$retirementage<-retirementage
        #df$term<-term
        str(df)
        df$Rewardswithoutcap<- as.double(Rewards)
        #df$Rewardswithcap<-ifelse( (df$investmenttype=="RP" | df$investmenttype=="SP"),ifelse((df$Rewardswithoutcap>4000),4000, df$Rewardswithoutcap),ifelse((df$Rewardswithoutcap>10000),10000,df$Rewardswithoutcap))
        df$Rewardswithcap<-ifelse( (df$investmenttype %in% c("RP", "SP")),
                                   ifelse(df$Rewardswithoutcap>4000,4000, df$Rewardswithoutcap),
                                   ifelse(df$Rewardswithoutcap>10000,10000,df$Rewardswithoutcap))
        
        wcsv <<- df
        
        df
    }) 
    
    
    
    # Finalplot<-renderPlot({
    #   
    #   
    #   #td<-aggregate(wcsv1$Rewardswithcap, by=list(Category=wcsv1$Policy.No), FUN=sum)
    #   p<-ggplot(data=wcsv1, aes(y=wcsv1$Rewardswithcap, x=Pol)) +
    #     geom_bar(stat="identity")
    # 
    #   p
    #   
    # }) 
    
})
